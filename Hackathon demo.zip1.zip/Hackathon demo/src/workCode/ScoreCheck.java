package workCode;

import java.util.ArrayList;
import java.util.Comparator;

public class ScoreCheck {
    private int winner;
    private String Player_ID;
    private Comparator<ScoreCheck> compared;
    public int getWinner() {
        return winner;
    }
    public void setWinner(int winner) {
        this.winner = winner;
    }
    public String getPlayer_ID(){
        return Player_ID;
    }
    public void setPlayer_ID(String ID){
        this.Player_ID = ID;
    }
    public ScoreCheck(int winner, int score, String ID){
        this.winner = winner;
        score = 0;
        this.Player_ID = ID;
    }
    public ArrayList<String> placing(ScoreCheck place_1,ScoreCheck Place_2){
        ArrayList<String> player_ranks = new ArrayList<>();
        int comp = compared.compare(place_1, Place_2);
        if(comp == -1){
            player_ranks.add(place_1.Player_ID);
            player_ranks.add(Place_2.Player_ID);
        }else{
            player_ranks.add(Place_2.Player_ID);
            player_ranks.add(place_1.Player_ID);
        }
        return player_ranks;
    }


}
