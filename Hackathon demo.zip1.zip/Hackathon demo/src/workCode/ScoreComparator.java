package workCode;

public class ScoreComparator extends comparator{
    public boolean  compare(ScoreCheck a, ScoreCheck b) {
       int a_ID = a.getWinner();
       int b_ID = b.getWinner();
       return a_ID < b_ID;
    }
}
